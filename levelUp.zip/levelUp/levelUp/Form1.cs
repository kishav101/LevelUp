﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;


using _Excel = Microsoft.Office.Interop.Excel;


namespace levelUp
{
    public partial class Form1 : Form
    {
        string path = "";
        int rowCount = 0;
        _Application excel = new _Excel.Application();
        Workbook wb;
        Worksheet ws;
        string[] MAIN_ALGORITHMS_ARRAY;
        string[] BONCAP_FIXED_FEES_464_465_470;
        string[] BARLOWORLD_SCHEME_RATES;
        string[] BONCAP_GP_NETWORK_BASE_RATE;



        public Form1()
        {
            InitializeComponent();
        }


        public void readExcelFile( string path, int sheet)
        {
            this.path = path;
            wb = excel.Workbooks.Open(path);
            ws = excel.Worksheets[sheet];
        }

        public void setRowCount()
        {
            rowCount = ws.UsedRange.Rows.Count;
        }

        public string readBonCapFixedFeesRows(int row, int col)
        {
            row++;
            col++;

            if(ws.Cells[row, col].Value2 != null)
            {
                return ws.Cells[row, col].Value2;
            }
            else
            {
                return "Empty";
            }

           // wb.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string file = "";

            if(textBox1.Text == "")
            {
                MessageBox.Show("Enter a excel line to view");
            }
            else
            {
                int num = Int32.Parse(textBox1.Text);
                num = num - 1;
                if (comboBox1.SelectedItem.ToString().Equals("BONCAP_FIXED_FEES_464_465_470"))
                {
                    file = "BONCAP_FIXED_FEES_464_465_470.xlsx";
                    BONCAP_FIXED_FEES_464_465_470 = algorithm(file);
                    MessageBox.Show(BONCAP_FIXED_FEES_464_465_470[num]);

                }
                if (comboBox1.SelectedItem.ToString().Equals("BARLOWORLD_SCHEME_RATES"))
                {
                    file = "BARLOWORLD_SCHEME_RATES.xlsx";
                    BARLOWORLD_SCHEME_RATES = algorithm(file);
                    MessageBox.Show(BARLOWORLD_SCHEME_RATES[num]);
                }
                if (comboBox1.SelectedItem.ToString().Equals("BONCAP_GP_NETWORK_BASE_RATE"))
                {
                    file = "BONCAP_GP_NETWORK_BASE_RATE.xlsx";
                    BONCAP_GP_NETWORK_BASE_RATE = algorithm(file);
                    MessageBox.Show(BONCAP_GP_NETWORK_BASE_RATE[num]);
                }
                

            }

        }

        private string [] algorithm(string filename)
        {

            readExcelFile(@"C:\Users\kisha\Desktop\levelUp\levelUp\"+filename, 1);
            setRowCount();

            MAIN_ALGORITHMS_ARRAY = new String[rowCount];
            string[] tempArr = new string[10];

            for (int i = 0; i < rowCount; i++)
            {
                for (int k = 0; k < 10; k++)
                {
                    tempArr[k] = readBonCapFixedFeesRows(i, k);
                }

                MAIN_ALGORITHMS_ARRAY[i] = (tempArr[1] + "#" + tempArr[2] + "#" + tempArr[3] + "#" + tempArr[4] + "#" + tempArr[5] + "#" + tempArr[6] + "#" + tempArr[7] + "#" + tempArr[8] + "#" + tempArr[9]);

            }

            return MAIN_ALGORITHMS_ARRAY;
        }
    }
}
